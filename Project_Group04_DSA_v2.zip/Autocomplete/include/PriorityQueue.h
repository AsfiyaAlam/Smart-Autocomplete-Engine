#ifndef PRIORITYQUEUE_H
#define PRIORITYQUEUE_H
#include <iostream>
#include <string>
#include "../src/SuggestionStruct.cpp"

//this is a custom comparator for comparing the struct Suggestion on the basis of priority
struct ComparePriority
{
    bool operator()(const Suggestion& p1 , const Suggestion& p2)
    {
    return p1.priority < p2.priority;
    }
};

#endif // PRIORITYQUEUE_H
