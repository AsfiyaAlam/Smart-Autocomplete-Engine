#ifndef TRIE_H
#define TRIE_H
#include <string>
#include <vector>
#include "../src/SuggestionStruct.cpp"

struct TrieNode
{
    //Each node has 26 potential paths where each can go
    TrieNode* children[26];
    //Determines if a specific node is an end of of word
    bool isWord;
    //Priority will be used later for sorting
    int priority;
    //Whenever a trie node is initialized it does not contain anything
    TrieNode()
    {
        isWord = false;
        for(int i = 0; i < 26; i ++)
        {
            children[i] = nullptr;
        }
    }
};

class Trie
{
    public:
        Trie();
        void insert(const std::string& word, int priority);
        bool search(const std::string& word);
        std::vector<Suggestion> getSuggestion(const std::string& prefix);
        void listConstructor(std::vector<Suggestion>* sugg,std::string prefix, TrieNode* current);
        virtual ~Trie();

    protected:

    private:
        TrieNode* root;

};

#endif // TRIE_H
