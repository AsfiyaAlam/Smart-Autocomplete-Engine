#ifndef DICTIONARYHANDLER_H
#define DICTIONARYHANDLER_H
#include <iostream>
#include <vector>
#include "string"
#include <filesystem>
#include "../src/SuggestionStruct.cpp"


class dictionaryHandler
{
    public:
        //constructor for the dictionary handler
        dictionaryHandler(std::string path);
        //function for converting the csv to vector
        std::vector<Suggestion> convertCSV();
        //desctrucotr
        virtual ~dictionaryHandler();

    protected:

    private:
        //privte filepath
        std::string filePath;
};

#endif // DICTIONARYHANDLER_H
