#include <iostream>
#include <queue>
#include <dictionaryHandler.h>
#include <filesystem>
#include "Trie.h"
#include "src/SuggestionStruct.cpp"
#include "PriorityQueue.h"

typedef std::priority_queue<Suggestion ,std::vector<Suggestion>, ComparePriority> PriorityQueue;
//this function is for checking the loop condition if the input was other then lowecase characters or empty it returns false
bool loopCondition(const std::string& str){
    if(str.empty()) return false;
    for(char ch : str)
        if(ch < 'a' || ch > 'z')
            return false;
    return true;
}
int main()
{
    bool isMod=false;
    char ch = 'n';
    std::string input;
    std::vector<Suggestion> suggVec;
    Trie testTrie;
    //these are the escape sequences for the colors
    const std::string red = "\033[31m";
    const std::string green = "\033[32m";
    const std::string blue = "\033[34m";
    const std::string reset = "\033[0m";


    //here we are initializing a dictionary handler object for reading data from the csv
    dictionaryHandler dict("moredata.csv");
    //this method actually reads data from the from csv and return a vector
    std::vector<Suggestion> vec = dict.convertCSV();
    //this loop insert data from the vector into the trie data structure
    for(int i = 0; i<vec.size(); i++){
        testTrie.insert(vec[i].word, vec[i].priority);
    }

    //this handles the input logic for the style prompt
    do{
        //this is to ensure that the output on the screen is pretty, we enquire at the start to select the style
        //as modern style on old terminal (windows 10 and old) causes random string which is basically ANSI escape sequences on the screen
        std::cout << "\nPress (n) for classic style and (y) for modern\n(note: modern works only for latest terminal applications otherwise print garbage values): ";
        std::cin >> ch;
        //i used this thing to flush the input stream as it was creating a mess if user entered a string instead of char
        while (std::cin.get() != '\n');
    }while(ch != 'y' && ch!= 'n');
    if(ch == 'y') isMod = true;

    //here we are actually taking words (prefixes) from the user and displaying the suggestions
    while(true){
        //creating a temporary priority queue for storing the most likely words for the prefixes
        PriorityQueue priority_temp;
        //prompting the user to enter the prefix
        std::cout << "\nEnter a word or character to search or press any other digit to exit: ";
        std::cin >> input;
        //if the user enters characters other than the lowercse the program will close
        if(!loopCondition(input)) break;
        //getting suggestions from the trie and storing them in suggestion vector
        suggVec = testTrie.getSuggestion(input);
        //this part is basically the check whether to use the escape sequence for styles or not
        if(isMod) std::cout << blue;

        std::cout <<"==============================\n";
        //this changes the color of the text after performing a check
        if(isMod) std::cout << green;

        std::cout <<"Suggestions for " << input << "\n\n";
        std::cout<<"------------------------------\n";
        //this resets the color of the text after performing a check
        if(isMod) std::cout << reset;
        //here the words are arranged by order of priority
        for(int i = 0; i<suggVec.size(); i++){
            priority_temp.push(suggVec[i]);
            //std::cout << suggVec[i].priority << "\t" << suggVec[i].word << "\n";
        }
        //number of output suggestions on screen
        int j = priority_temp.size();
        if(j>10) j=10;
        //displaying the suggestions
        for(int i = 0; i<j; i++){
            //highlighting the first suggestion
            if(i == 0 && isMod) std::cout << red;
            std::cout << priority_temp.top().priority << "\t" << priority_temp.top().word << "\n";
            priority_temp.pop();
            //reset the color
            if(i == 0 && isMod) std::cout << reset;
        }
        //setting and unsetting the color for the style
        if(isMod) std::cout << blue;
        std::cout <<"==============================\n";
        if(isMod) std::cout << reset;
    }


}
