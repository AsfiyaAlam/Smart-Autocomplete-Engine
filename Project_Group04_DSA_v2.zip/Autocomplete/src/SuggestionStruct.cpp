#ifndef STRUCT_H
#define STRUCT_H
#include <string>
//struct for a Suggetion containing the actual word and priority
struct Suggestion
{
    std::string word;
    int priority;
    Suggestion(const std::string& otherWord, int otherPriority)
    {
        word = otherWord;
        priority = otherPriority;

    }
};
#endif
