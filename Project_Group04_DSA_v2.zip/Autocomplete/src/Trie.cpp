#include "Trie.h"
#include <iostream>

Trie::Trie()
{
    //at start Trie is empty
    root = new TrieNode();
}

Trie::~Trie()
{
    //dtor
}
void Trie::insert(const std::string& word, int priority)
{
    TrieNode* current = root;
    for(char letter : word)
    {
        int index = letter - 'a';
        if(current->children[index] == nullptr)
        {
            //Create a new node at the place of the new letter
            current->children[index] = new TrieNode();
        }
        //Move to the newly created node
        current = current->children[index];
    }
    //After the for loop is done we will have a new word
    current->isWord = true;
    //Also set the words priority
    current ->priority = priority;
}

bool Trie::search(const std::string& word)
{
    //We will start searcing from the root
    TrieNode* current = root;
    //Now we will go throuh the whole string
    for(char letter : word)
    {
        //Index is the current letter
        int index = letter - 'a';
        //If there is no letter at a certain index then this means the rest of the string is also not there so we return false
        if(current->children[index] == nullptr)
        {
            return false;
        }
        //Go to the children for the next iteration
        current = current->children[index];
    }
    //We will only return true if the current is also a word so we will just return its statuss
    return current->isWord;

}
std::vector<Suggestion> Trie::getSuggestion(const std::string& prefix)
{
    std::vector<Suggestion> sugg;
    TrieNode* current = root;
    //int s1 =10;
    //std::string s2 = "hello";
    //sugg.push_back({s2,s1});
    for(char letter : prefix){
        int index = letter - 'a';
        if(current->children[index]!=nullptr)
            //getting to the last node based on the prefix
            current = current->children[index];
        else return sugg;
    }
    //calling a helper funtion to build the vector
    listConstructor(&sugg, prefix, current);
    return sugg;

}
//this is the helper funtion which create a vector of words by recursively calling itself basically it is depth first search
void Trie::listConstructor(std::vector<Suggestion>* sugg,std::string prefix, TrieNode* current){
    char ch;
    //if the current node is endofword we will push it into the vector
    if(current->isWord){
            sugg->push_back({prefix, current->priority});
    }
    //we will traverse all the not null nodes in the array
    for(int i=0; i<26; i++){
        if(current->children[i] != nullptr){
            ch = (char)(i+'a');
            //passing the prefix+charachter
            listConstructor(sugg, prefix+ch, current->children[i]);
        }
    }
}

