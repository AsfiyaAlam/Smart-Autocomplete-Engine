#include "dictionaryHandler.h"
#include "string"
#include "iostream"
#include <vector>
#include <fstream>
#include <sstream>
#include <filesystem>

//this is the constructor of the class which just sets the path of the csv file
dictionaryHandler::dictionaryHandler(std::string path)
{
    filePath = path;
}
//this is the desctructor
dictionaryHandler::~dictionaryHandler()
{
    //dtor
}

//this method is for reading the csv line by line and entering the word and its priority in a vector<Suggestions>
std::vector<Suggestion> dictionaryHandler::convertCSV(){
    std::vector<Suggestion> wordList;
    //this reads a file from the disk
    std::ifstream file(filePath);
    //this checks if the file is open or not
    if(!file.is_open()){
        std::cerr << "Can't open file: " << filePath << "\n";
        //if the file is not open we will return the empty vector
        return wordList;
    }
    //std::cout << "success";
    //this is the string variable for reading lines from the file
    std::string line;
    bool skipHeader = true;
    //continue the loop till the end of file
    //getline function reads line from the file and store it in the line variable
    while(std::getline(file,line)){
        if(skipHeader){
            skipHeader = false;
            continue;
        }
        //varibles for storing the word and its priority
        std::string word, freqStr;
        //this create string stream from the line string
        std::stringstream ss(line);
        //if line is empty we skip it
        if(line.empty()) continue;
        //we read the string stream until hit by a comma in the csv and put that in the word variable
        if(!std::getline(ss,word,',')) continue;
        //we continue reading the string stream until again hit by a comma in the csv and put that in the freqStr
        if(!std::getline(ss,freqStr,',')) continue;
        //try to push the word in the vector
        try{
            //casting the freq to an integer
            int priority = std::stoi(freqStr);
            //pushing the word and its priority in the vector<Suggestion>
            wordList.push_back({word,priority});
        }catch(...){
            //if it fails then skip and try to read next line
            continue;
        }
    }
    //returing the vector
    return wordList;
}
